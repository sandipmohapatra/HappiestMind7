package com.example.demo;
import org.springframework.jdbc.core.JdbcTemplate;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class TestController 
{
@Autowired
private JdbcTemplate jt;
private HttpServletRequest req;
private HttpServletResponse res;

@GetMapping("/show")
public String showRegister()
{
	return "First";
}
@RequestMapping("/register")
public String doRegistration(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	res.setContentType("text/html");
	PrintWriter pw=res.getWriter();
	String a=req.getParameter("t1");
	String b=req.getParameter("t2");
	String c=req.getParameter("t3");
	String sql="insert into employee values(?,?,?)";
	int count=jt.update(sql,a,b,c);
	pw.println("row inserted"+count);
		return "success";
	
}

}
// create table employee (empno varchar(30),name varchar(30),address varchar(30));