package org.jdbc;

public class GetOnePerson 
{
public static void main(String[] args) 
{
PersonDao dao=new JdbcPersonDao();
int id=101;
Person p=dao.getPerson(id);
if(p==null)
System.out.println("Person data not there");
else
	System.out.println(p);
}
}
