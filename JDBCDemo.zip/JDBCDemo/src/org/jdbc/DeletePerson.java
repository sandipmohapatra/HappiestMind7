package org.jdbc;

public class DeletePerson 
{
public static void main(String[] args) 
{
PersonDao dao=new JdbcPersonDao();
int id=101;
dao.deletePerson(id);
System.out.println("Person data deleted");
}
}
