package org.jdbc;
import java.sql.*;
import java.util.*;
public class FirstJdbc 
{
	public static void main(String[] args)throws Exception
	{
		Connection con=null;
		Scanner ob=new Scanner(System.in);
		con=DbUtil.getConnection();
		System.out.println("enter your choice");
		System.out.println("1.Create Table");
		System.out.println("2.Insert Data");
		System.out.println("3.Update Data");
		System.out.println("4.Delete Data");
		System.out.println("5.Select Data");
		int c=ob.nextInt();
		switch(c)
		{
		
		case 1:PreparedStatement st=con.prepareStatement("CREATE TABLE BANK "
				+ "(ACCNO INT NOT NULL AUTO_INCREMENT, NAME VARCHAR(30) NOT NULL,"
				+ "ADDRESS VARCHAR(30) NOT NULL,PRIMARY KEY(ACCNO))");
		st.execute();
		System.out.println("Table created");
		break;
		
		case 2:System.out.println("enter name,address");
		String name=ob.next();
		String add=ob.next();
		PreparedStatement st1=con.prepareStatement("insert into bank(name,address) values(?,?)");
		st1.setString(1, name);
		st1.setString(2,add);
		st1.execute();
		System.out.println("row inserted");
		break;	
		
		case 3:System.out.println("enter name,address and accno you want to update");
		String name1=ob.next();
		String add1=ob.next();
		int acc=ob.nextInt();
		PreparedStatement st2=con.prepareStatement("update bank set name=?,address=? where accno=?");
		st2.setString(1, name1);
		st2.setString(2,add1);
		st2.setInt(3,acc);
		st2.execute();
		System.out.println("row update");
		break;	
		
		case 4:System.out.println("enter accno you want to delete");
		int acc1=ob.nextInt();
		PreparedStatement st3=con.prepareStatement("delete from bank where accno1=?");
		st3.setInt(1,acc1);
		st3.execute();
		System.out.println("row delete");
		break;	
		
		case 5:PreparedStatement st4=con.prepareStatement("select * from bank");
		ResultSet rs=st4.executeQuery();
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
		}
		break;	
		default:System.out.println("invalid input");
		}
	}}