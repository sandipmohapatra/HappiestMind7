package org.jdbc;
import java.sql.*;
import java.util.*;
public class JdbcPersonDao implements PersonDao
{

	@Override
	public void addPerson(Person person) 
	{
		Connection conn=null;
		PreparedStatement st=null;
		try
		{
			String sql="insert into person values(?,?,?,?,?)";
			conn=DbUtil.getConnection();
			st=conn.prepareStatement(sql);
			st.setInt(1, person.getId());
			st.setString(2, person.getFirstName());
			st.setString(3, person.getLastName());
			st.setString(4, person.getPhone());
			st.setString(5, person.getEmail());
			st.execute();
		} 
		catch (Exception e) 
		{
					e.printStackTrace();
		}
		
		
		
	}

	@Override
	public Person getPerson(int id) 
	{
		Connection conn=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		try
		{
			String sql="select * from person where id=?";
			conn=DbUtil.getConnection();
			st=conn.prepareStatement(sql);
			st.setInt(1,id);
			rs=st.executeQuery();
			if(rs.next())
			{
				Person person=getPersonFromResultSet(rs);
				return person;
			}}
			catch(Exception ae)
		{
				ae.printStackTrace();
		}
		return null;
	}

	private Person getPersonFromResultSet(ResultSet rs) throws SQLException 
	{
	Person person=new Person();
	person.setId(rs.getInt("id"));
	person.setFirstName(rs.getString("firstname"));
	person.setLastName(rs.getString("lastname"));
	person.setPhone(rs.getString("phone"));
	person.setEmail(rs.getString("email"));
			return person;
	}

	@Override
	public void updatePerson(Person person)  {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePerson(int id)  {
		Connection conn=null;
		PreparedStatement st=null;	
		try
		{
			String sql="delete from person where id=?";
			conn=DbUtil.getConnection();
			st=conn.prepareStatement(sql);
			st.setInt(1,id);
			if(st.executeUpdate()==0)
			{
				throw new Exception("No Data found");
			}
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
	}

	@Override
	public List getAllPersons() {
		Connection conn=null;
		PreparedStatement st=null;
		ResultSet rs=null;
		List list=new ArrayList(); 
		try
		{
			String sql="select * from person";
			conn=DbUtil.getConnection();
			st=conn.prepareStatement(sql);
			rs=st.executeQuery();
			while(rs.next())
			{
				Person person=getPersonFromResultSet(rs);
				list.add(person);
			}
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return list;
	}

	@Override
	public Person getPersonByPhone(String phone)  {
		// TODO Auto-generated method stub
		return null;
	}

}