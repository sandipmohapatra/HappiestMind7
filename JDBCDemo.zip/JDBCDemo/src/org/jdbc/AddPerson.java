package org.jdbc;
public class AddPerson 
{
public static void main(String[] args) throws Exception
{
Person person =new Person(101,"sandip","kumar","9988776655","sandip@gmail.com");
PersonDao dao=new JdbcPersonDao();
dao.addPerson(person);
System.out.println("******************"+person.getId());
System.out.println("Person data added");
}
}
