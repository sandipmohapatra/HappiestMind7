package org.jdbc;
import java.util.List;
public class GetAllPersons 
{
public static void main(String[] args) 
{
PersonDao dao=new JdbcPersonDao();
List <Person>list=dao.getAllPersons();
for(Person p : list)
{
System.out.println(p.getId()+" "+p.getFirstName()+" "+p.getLastName());
}
}
}
