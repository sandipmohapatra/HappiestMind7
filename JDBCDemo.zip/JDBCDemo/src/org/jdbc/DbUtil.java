package org.jdbc;
import java.sql.*;
public class DbUtil 
{
public static Connection getConnection() throws Exception
{
	String driver,url,user,password;
	driver="com.mysql.jdbc.Driver";
	url="jdbc:mysql://localhost:3306/happiestmind";
	user="root";
	password="1234";
	Class.forName(driver);
	return DriverManager.getConnection(url,user,password);
}
}
