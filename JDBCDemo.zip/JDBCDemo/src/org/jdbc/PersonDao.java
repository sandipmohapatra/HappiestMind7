package org.jdbc;
import java.util.List;
public interface PersonDao 
{
public void addPerson(Person person);
public Person getPerson(int id);
public void updatePerson(Person person);
public void deletePerson(int id);

public List getAllPersons();
public Person getPersonByPhone(String phone);
}
