package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcExample16Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcExample16Application.class, args);
	}

}
