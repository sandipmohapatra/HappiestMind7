//setter Injection   
public class Student {  
private String name,address,phoneno;  
  
public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getPhoneno() {
	return phoneno;
}

public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}

public String getName() {  
    return name;  
}  
  
public void setName(String name) {  
    this.name = name;  
}  
  
public void displayInfo(){  
    System.out.println("Hello: "+name); 
    System.out.println("The address is "+address);
    System.out.println("The phoneno is "+phoneno);
}  
}  