package com.cognizant.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cognizant.model.Book;
import com.cognizant.model.Subject;

public class EntityDaoImpl implements EntityDao {
	private SessionFactory sessionFactory;

	public EntityDaoImpl() {
		setSessionFactory(new Configuration().configure().buildSessionFactory());
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void addSubject(Subject subject) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			session.save(subject);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			closeSession(session);
		}
	}

	@Override
	public void addBook(Book book) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			session.save(book);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			closeSession(session);
		}
	}

	@Override
	public void deleteSubject(long subjectId) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Subject subject = (Subject) session.load(Subject.class, subjectId);
			session.delete(subject);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			closeSession(session);
		}
	}

	@Override
	public Subject searchSubject(long subjectId) {
		Session session = null;
		Subject subject = null;
		try {
			session = sessionFactory.openSession();
			subject = (Subject) session.get(Subject.class, subjectId);
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			closeSession(session);
		}
		return subject;
	}

	@Override
	public void deleteBook(long bookId) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			session.beginTransaction();
			Book book = (Book) session.load(Book.class, bookId);
			session.delete(book);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			closeSession(session);
		}
	}

	@Override
	public Book searchBook(long bookId) {
		Session session = null;
		Book book = null;
		try {
			session = sessionFactory.openSession();
			book = (Book) session.get(Book.class, bookId);
		} catch (HibernateException e) {
		e.printStackTrace();
		} finally {
			closeSession(session);
		}
		return book;
	}

	@Override
	public List<Subject> showAllSubjects() {
		Session session = null;
		List<Subject> subjectList = null;
		try {
			session = sessionFactory.openSession();
			Criteria subjectCriteria = session.createCriteria(Subject.class);
			subjectList = subjectCriteria.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			closeSession(session);
		}
		return subjectList;
	}

	@Override
	public List<Book> showAllBooks() {
		Session session = null;
		List<Book> bookList = null;
		try {
			session = sessionFactory.openSession();
			Criteria bookCriteria = session.createCriteria(Book.class);
			bookList = bookCriteria.list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
		closeSession(session);
		}
		return bookList;
	}

	public void closeSession(Session session) {
		// session.flush();
		session.close();
	}
}
