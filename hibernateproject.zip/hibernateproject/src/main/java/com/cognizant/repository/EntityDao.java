package com.cognizant.repository;

import java.util.List;

import com.cognizant.model.Book;
import com.cognizant.model.Subject;

public interface EntityDao {
	public void addSubject(Subject subject);
	public void addBook(Book book);
	public void deleteSubject(long subjectId);
	public Subject searchSubject(long subjectId);
	public void deleteBook(long bookId);
	public Book searchBook(long bookId);
	public List<Subject> showAllSubjects();
	public List<Book> showAllBooks();
}
