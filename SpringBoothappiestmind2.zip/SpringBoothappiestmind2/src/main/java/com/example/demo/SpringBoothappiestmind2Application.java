package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoothappiestmind2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoothappiestmind2Application.class, args);
	}

}
