package com.example.demo;
import java.util.Map;
import java.util.Properties;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

//ctrl+shift+O
@Component

public class MyMessage2 implements CommandLineRunner,Ordered
{
	public void run(String... args) throws Exception 
	{
			System.out.println("This is Madhu order-2");	
	}

	public int getOrder() {
		
		return 2;
	}
	
}
