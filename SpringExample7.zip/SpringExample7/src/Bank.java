public class Bank 
{
int accno;
String name;
float bal;
public Bank() 
{
	super();
}
public Bank(int accno, String name, float bal) 
{
	super();
	this.accno = accno;
	this.name = name;
	this.bal = bal;
}
@Override
public String toString() {
	return "Bank [accno=" + accno + ", name=" + name + ", bal=" + bal + "]";
}


}
