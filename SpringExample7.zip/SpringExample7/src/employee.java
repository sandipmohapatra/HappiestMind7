import java.util.Iterator;  
import java.util.List;  
public class employee 
{  
	private int id;  
	private String name;  
	private List<Bank> bank;  
	public employee() //default constructor
	{}  
	public employee(int id, String name, List<Bank> bank) //parameterized constructor with 3 args
	{  
		super();  
		this.id = id;  
		this.name = name;  
		this.bank=bank;
	}  
	public void displayInfo()
	{  
		System.out.println("employee id :"+id+" Name is :"+name);  
		System.out.println("Bank are:");  
		Iterator<Bank> itr=bank.iterator();  
		while(itr.hasNext())
		{  
			System.out.println(itr.next());  
		}}  

}  