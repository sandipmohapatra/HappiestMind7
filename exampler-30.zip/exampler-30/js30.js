var Name =prompt("Enter your name");
var Address =prompt("Enter your address");

if(Name=="" && Address=="")
{
console.log("Name and Address is empty");
}
else
{
console.log("Hello !"+Name);
}
