package com.javatpoint;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@Controller  
public class HelloWorldController {  

	@RequestMapping("/hello")  
	public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) throws IOException 
	{  
		PrintWriter pw=res.getWriter();
		res.setContentType("text/html");
		String a =request.getParameter("t1");
		String b =request.getParameter("t2");
		String c =request.getParameter("t3");
		String d=request.getParameter("b1");
		pw.println(d);
		String x=null;
		try 
		{ 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");	
			if(d.equals("insert"))
			{
				PreparedStatement st=con.prepareStatement("insert into  employee values(?,?,?)");
				st.setString(1,a);
				st.setString(2,b);
				st.setString(3,c);
				st.execute();
				x="row inserted";
			}
			else if(d.equals("update"))
			{
				PreparedStatement st=con.prepareStatement("update employee set name=?,pass=? where empno=?");
				st.setString(1,b);
				st.setString(2,c);
				st.setString(3,a);
				st.execute();
				x="row updated";	
			}

			else if(d.equals("delete"))
			{
				PreparedStatement st=con.prepareStatement("delete from employee where empno=?");
				st.setString(1,a);
				st.execute();
			x="row deleted";	
			}
			else if(d.equals("SelectByID"))
			{
				PreparedStatement st=con.prepareStatement("select * from employee where empno=?");
				st.setString(1,a);
				ResultSet rs=st.executeQuery();
				while(rs.next())
				{
			x= rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3);
				}
			}
			else
			{
				pw.println("wrong input");
			}

		}catch(Exception e) 
		{
			e.printStackTrace();
		}
		String message = x;  
		return new ModelAndView("hellopage", "message",message);  

	}
	}