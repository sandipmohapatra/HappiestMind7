package com.example.demo;

import org.springframework.stereotype.Component;

@Component("obj")
public class Squareno 
{

	public int squareno(int x)
	{
		return x*x;
	}
	
	public int cubeno(int x)
	{
		return x*x*x;
	}
}
